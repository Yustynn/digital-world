def foreach(f, it):
    for el in it:
        f(el)

